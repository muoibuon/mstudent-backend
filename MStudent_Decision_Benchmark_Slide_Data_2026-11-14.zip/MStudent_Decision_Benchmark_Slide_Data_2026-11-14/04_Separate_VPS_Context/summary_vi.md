# Phụ lục riêng: trạng thái VPS

Snapshot chỉ đọc ngày 14/11/2026, khoảng 14:46–14:49 giờ Việt Nam:

| Mục | Quan sát |
|---|---|
| MStudent | active/running, 0 restart |
| CPU | 2 vCPU, load average 0.05 / 0.10 / 0.09 |
| RAM | 758 / 3.855 MiB đang dùng, 3.097 MiB available |
| Đĩa | 17% sử dụng |
| Web và health qua HTTPS | HTTP 200 |
| Backup gần nhất | Thành công theo trạng thái service; chưa thử restore |

Đây là kiểm tra vận hành riêng. Không dùng cấu hình/tài nguyên VPS này để mô tả môi trường benchmark; benchmark chạy từ máy kiểm tra qua API, không được chứng minh chạy trên VPS này. Health tại thời điểm kiểm tra chưa báo bộ lọc Decision v1 đang hoạt động. Không restart/deploy hoặc sửa cấu hình khi kiểm tra.
