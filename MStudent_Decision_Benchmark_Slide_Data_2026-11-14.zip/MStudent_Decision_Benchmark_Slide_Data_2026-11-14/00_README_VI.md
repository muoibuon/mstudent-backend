# Gói số liệu MStudent dành cho đội làm slide

Ngày chốt số liệu: 14/11/2026. Phạm vi: so sánh hai workflow bằng API thật trên dữ liệu tổng hợp.

## Đọc theo thứ tự

1. `01_Slide_Data/summary_metrics.csv`: bảng số chính, đơn vị và ghi chú; có thể mở bằng Excel/Google Sheets.
2. `01_Slide_Data/chart_data.csv`: dữ liệu dạng dài, thuận tiện vẽ biểu đồ cột.
3. `01_Slide_Data/segments.csv`: tách 16 tin nhiễu và 44 tin hữu ích.
4. `01_Slide_Data/anchor_quality.csv`: 12 ca kiểm tra hạn/môn, phải trình bày tách mẫu chính.
5. `02_Report/benchmark_report_vi.md`: thiết kế, kết quả, khoảng tin cậy và các ca lệch kỳ vọng.
6. `03_Raw_Data/`: dữ liệu từng lượt, protocol và phân tích chi tiết để đối chiếu.

CSV dùng UTF-8 có BOM, dấu phẩy phân cột, dấu chấm thập phân; không đổi đơn vị hoặc làm tròn trước khi tính phần trăm.

## Những số có thể đưa lên slide

- 60 ca nghiệm thu, mỗi ca chạy hai workflow; thêm 12 ca có đáp án hạn/môn. Tổng 144 lượt xử lý ca, không phải 144 API request.
- LLM-only trong bài là luồng hiện có `Triage → Extractor`; không phải baseline LLM gộp một lượt đã tối ưu lại.
- Lượt LLM chính: 97 → 46, giảm 52,6%.
- Tổng request gồm Decision: 97 → 106, tăng 9,3%.
- Thời gian trung vị: 7,2919 → 5,74845 giây, giảm 21,2%.
- P95: 9,9278 → 9,9666 giây, gần như không đổi, tăng 0,4%.
- Khớp lọc + nhãn: 50/60 → 59/60; đây không phải độ đúng toàn bộ task.
- Giữ được tin hữu ích: 37/44 → 44/44; loại đúng tin nhiễu: 16/16 ở cả hai workflow.
- Hai lần Decision timeout được giữ nguyên và fallback thành công; không loại khỏi số đo.

## Chú thích tối thiểu nên giữ trên slide

“API thật, dữ liệu tổng hợp: 60 ca so sánh ghép cặp, một lượt mỗi workflow/ca; cùng LLM chính. Đo classifier và sanitize, không gồm tải nguồn/UI. Khác biệt chất lượng gồm cả prompt/chính sách lọc. Chi phí main là ước tính theo giá cấu hình, chưa phải hóa đơn gateway.”

Không trình bày “giảm 52,6% tổng API request”, “nhanh hơn 21,2% trong mọi tình huống”, “độ chính xác production 98,3%” hoặc “tiết kiệm tiền thật 28,4%”. P95 chưa cải thiện. Chưa thử inbox thật, tải đồng thời hoặc nhiều ngày.

## Dữ liệu chia sẻ

Nội dung ca là dữ liệu tổng hợp. Gói không có khóa API, mật khẩu, `.env`, database hoặc mã đăng nhập. Địa chỉ gateway vận hành đã được thay bằng nhãn, không cần truy cập dịch vụ để dùng dữ liệu.

Phụ lục VPS chỉ là trạng thái vận hành riêng, không phải phần cứng hay môi trường benchmark. Phụ lục không có IP, domain, username hoặc fingerprint triển khai.

`SHA256SUMS.txt` dùng đối chiếu tính toàn vẹn các file. Số gốc trong JSON/CSV ưu tiên hơn số đã làm tròn trên slide.
