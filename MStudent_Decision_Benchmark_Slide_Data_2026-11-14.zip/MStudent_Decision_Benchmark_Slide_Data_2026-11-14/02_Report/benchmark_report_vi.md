# LLM-only và Decision + LLM — benchmark ghép cặp

Ngày 14/11/2026. API thật, dữ liệu tổng hợp, không dùng inbox hoặc OAuth thật.

## Thiết kế đã cố định trước khi chạy

- Mã nguồn: `ccd6752f2a2405cc767de9b163f610739107ce64`; working tree sản phẩm không thay đổi trong bài test.
- 60 ca nghiệm thu: mỗi ca chạy cả hai luồng. Thêm 12 ca cũ có đáp án hạn/môn, phân tích riêng.
- Thứ tự ca được xáo trộn bằng seed 20261114; vị trí A trước/B trước cân bằng. Chạy tuần tự, không concurrency.
- A, LLM-only: Triage bằng LLM chính, rồi Extractor nếu tin liên quan. Đây là baseline hai bước đang có trong backend.
- Prompt Triage cũ thiên về việc cần làm/mốc thời gian; Decision v1 còn giữ tài liệu học vụ hữu ích. Khác biệt chất lượng vì vậy gồm cả chính sách/prompt lọc, không chỉ năng lực model.
- B, Decision + LLM: gate hiện tại, với stop/direct/review/fallback. Hai bên dùng cùng model và endpoint chính.
- Main model yêu cầu: `cx/gpt-6-luna(xhigh)`; Decision: `google/gemini-decision-1`.
- Ngưỡng: `{'low': 0.1, 'high': 0.8, 'category_conf': 0.75}`. Timeout main 25.0 s, Decision 8.0 s.
- Warm-up một request cho mỗi provider, loại khỏi số liệu. Không tự retry hoặc chọn lại các kết quả xấu.
- Đo classifier và sanitize đầu ra; không gồm tải nguồn, planner ghi DB, làm giàu sự kiện, chat hoặc UI.
- Không so với một LLM-only được thiết kế lại để gộp phân loại/trích việc thành một call; hiệu quả dưới đây thuộc hai workflow cụ thể.
- Bộ ca đã từng được dùng trong các kiểm tra trước của dự án; không phải tập dữ liệu mới mù hoàn toàn hay phân bố người dùng production.

## Kết quả chính — 60 ca nghiệm thu

| Chỉ số | LLM-only | Decision + LLM |
|---|---:|---:|
| Khớp lọc + nhãn kỳ vọng | 50/60 | 59/60 |
| Lọc liên quan đúng | 53/60 | 60/60 |
| Giữ được tin hữu ích | 37/44 | 44/44 |
| Loại được tin nhiễu | 16/16 | 16/16 |
| Nhãn đúng trên tin hữu ích | 34/44 | 43/44 |
| Lượt LLM chính | 97 | 46 |
| Lượt Decision | 0 | 60 |
| Latency trung vị (p50) | 7.29 s | 5.75 s |
| Latency p95 | 9.93 s | 9.97 s |
| Thời gian trung bình | 6.61 s | 5.52 s |
| Offline hoặc lỗi cuối cùng | 0 | 0 |
| Tin hữu ích bị gate stop | Không có gate | 0 |
| Lỗi Decision đã được fallback/xử lý | 0 | 2 |

So với A: lượt main đổi **-52.6%**, p50 đổi **-21.2%**, p95 đổi **+0.4%**. Dấu âm là giảm.

## Độ không chắc chắn

Bootstrap ghép cặp 2.000 lần trên 60 ca: khoảng 95% cho thay đổi p50 là **[-27.0%, -1.0%]**.
Chênh lệch accuracy (B trừ A): khoảng bootstrap 95% **[+6.7, +25.0] điểm phần trăm**.
Các cặp bất đồng: chỉ A đúng 0, chỉ B đúng 9; McNemar exact hai phía p=0.003906 (thăm dò).
Đây là benchmark cùng case, không phải chia traffic người dùng nên kiểm tra SRM traffic không áp dụng. Một lượt/case và mẫu tổng hợp không chứng minh tương đương chất lượng hay tốc độ production; bootstrap không bao phủ biến động provider qua nhiều ngày.

## Token và chi phí

| Chỉ số | LLM-only | Decision + LLM |
|---|---:|---:|
| Input token main | 139023 | 79136 |
| Output token main | 12783 | 7652 |
| Input token Decision | 0 | 27979 |
| Phí Decision provider báo, USD | 0.0000000 | 0.0027336 |
| Phí Decision lỗi phải ước tính, USD | 0.0000000 | 0.0000643 |
| Phí main ước tính, USD | 0.0202938 | 0.0117396 |
| Tổng theo mô hình giá ước tính, USD | 0.0202938 | 0.0145375 |

Main đang dùng giá cấu hình 0.1 USD/1M input và 0.5 USD/1M output để ước tính ngân sách. Chưa xác nhận đây là bảng giá gateway; không coi các dòng ước tính là hóa đơn thật. Token của lượt lỗi có thể cũng được ước tính.
Điều kiện hòa vốn với giá main thực P_in/P_out (USD/1M token): `0.059887 × P_in + 0.005131 × P_out > 0.0027979`. Vế phải gồm phí Decision báo và ước tính lỗi, nếu có.

## Theo nhóm dữ liệu

| Nhóm | Số ca | p50 A | p50 B | Lượt main A | Lượt main B |
|---|---:|---:|---:|---:|---:|
| Tin nhiễu | 16 | 2.88 s | 1.66 s | 16 | 1 |
| Tin hữu ích | 44 | 8.01 s | 6.42 s | 81 | 45 |

## 12 ca kiểm tra hạn/môn (tách khỏi mẫu chính)

| Chỉ số | LLM-only | Decision + LLM |
|---|---:|---:|
| Lọc đúng | 12/12 | 12/12 |
| Nhãn đúng | 9/9 | 9/9 |
| Hạn đúng | 6/8 | 7/8 |
| Môn đúng | 2/2 | 2/2 |
| Khớp toàn bộ kỳ vọng | 10/12 | 11/12 |

Chỉ 12 ca có nhãn trích xuất chi tiết; mẫu 60 ca chính chấm lọc/phân loại, không chứng minh mọi task trích xuất đều đúng. Đầu ra task của cả hai bên được giữ trong JSON để kiểm tra.

## Các ca lệch kỳ vọng

### Mẫu 60 ca
- `a010`: expected `{"relevant": true, "category": "admin"}`; A checks `{'relevant': True, 'category': False}`; B checks `{'relevant': True, 'category': True}`, route B `direct`.
- `o011`: expected `{"relevant": true, "category": "other"}`; A checks `{'relevant': False, 'category': False}`; B checks `{'relevant': True, 'category': True}`, route B `review`.
- `o002`: expected `{"relevant": true, "category": "other"}`; A checks `{'relevant': False, 'category': False}`; B checks `{'relevant': True, 'category': True}`, route B `direct`.
- `o010`: expected `{"relevant": true, "category": "other"}`; A checks `{'relevant': False, 'category': False}`; B checks `{'relevant': True, 'category': True}`, route B `direct`.
- `a007`: expected `{"relevant": true, "category": "admin"}`; A checks `{'relevant': True, 'category': False}`; B checks `{'relevant': True, 'category': True}`, route B `direct`.
- `v011`: expected `{"relevant": true, "category": "event"}`; A checks `{'relevant': False, 'category': False}`; B checks `{'relevant': True, 'category': True}`, route B `direct`.
- `v005`: expected `{"relevant": true, "category": "event"}`; A checks `{'relevant': False, 'category': False}`; B checks `{'relevant': True, 'category': True}`, route B `direct`.
- `o008`: expected `{"relevant": true, "category": "other"}`; A checks `{'relevant': False, 'category': False}`; B checks `{'relevant': True, 'category': True}`, route B `direct`.
- `o005`: expected `{"relevant": true, "category": "other"}`; A checks `{'relevant': False, 'category': False}`; B checks `{'relevant': True, 'category': True}`, route B `direct`.
- `a002`: expected `{"relevant": true, "category": "admin"}`; A checks `{'relevant': True, 'category': False}`; B checks `{'relevant': True, 'category': False}`, route B `direct`.
### Ca hạn/môn
- `anchor-09`: expected `{"relevant": true, "category": "exam", "due": "2026-11-11"}`; A checks `{'relevant': True, 'category': True, 'due': False}`; B checks `{'relevant': True, 'category': True, 'due': True}`, route B `direct`.
- `anchor-05`: expected `{"relevant": true, "category": "event", "due": "2026-11-20T17:00"}`; A checks `{'relevant': True, 'category': True, 'due': False}`; B checks `{'relevant': True, 'category': True, 'due': False}`, route B `direct`.

## File đối chiếu trong gói

- `../03_Raw_Data/results.json`: từng lượt xử lý, output, trace, usage và latency.
- `../03_Raw_Data/analysis.json`: tổng hợp đầy đủ và thống kê ghép cặp.
- `../03_Raw_Data/protocol.json`: thiết kế và cấu hình; địa chỉ gateway vận hành đã ẩn.
- `../03_Raw_Data/cases.csv`: bảng từng ca.

Không sửa mã nguồn sản phẩm, ngưỡng, prompt hoặc đáp án trong khi chạy. Model alias được gateway chấp nhận chưa chứng minh model upstream thực tế. Không có thao tác deploy trong benchmark.
